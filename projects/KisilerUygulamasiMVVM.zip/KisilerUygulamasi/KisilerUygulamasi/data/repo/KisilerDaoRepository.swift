//
//  KisilerDaoRepository.swift
//  KisilerUygulamasi
//
//  Created by Çağın Böğürcü on 15/03/24.
//

import Foundation
import RxSwift


class KisilerDaoRepository{
    
    var kisilerListesi = BehaviorSubject<[Kisiler]>(value: [Kisiler]())
    
    func kaydet(kisi_ad: String, kisi_tel: String) {
        print("Kisi Kaydet: \(kisi_ad) - \(kisi_tel)")
    }
    
    func guncelle(kisi_id:Int, kisi_ad:String, kisi_tel:String) {
        print("Kisi guncelle: \(kisi_id) - \(kisi_ad) - \(kisi_tel)")
    }
    
    func sil(kisi_id:Int){
        print("Kisi Sil: \(kisi_id)")
        kisileriYukle()
    }
    
    func ara(aramaKelimesi:String){
        print("Kisi Ara : \(aramaKelimesi)")
    }
    
    func kisileriYukle() {
        var liste = [Kisiler]()
        let k1 = Kisiler(kisi_id: 1, kisi_ad: "ahmet", kisi_tel: "1212")
        let k2 = Kisiler(kisi_id: 2, kisi_ad: "mehmet", kisi_tel: "123123")
        let k3 = Kisiler(kisi_id: 3, kisi_ad: "veli", kisi_tel: "123123112")
        
        liste.append(k1)
        liste.append(k2)
        liste.append(k3)
        
        kisilerListesi.onNext(liste)
    }
}
