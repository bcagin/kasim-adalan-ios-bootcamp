//
//  AnasayfaViewModel.swift
//  FilmlerApp
//
//  Created by Çağın Böğürcü on 16/03/24.
//

import Foundation
import RxSwift

class AnasayfaViewModel {
    
    var frepo = FilmlerDaoRepository()
    var filmlerListesi = BehaviorSubject<[Filmler]>(value: [Filmler]())
    
    init(){
        filmlerListesi = frepo.filmlerListesi
        frepo.filmleriYukle()
    }
    
    func filmleriYukle(){
        frepo.filmleriYukle()
    }
    
}
